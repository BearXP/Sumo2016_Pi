Python Serial Port Extension for Win32, OSX, Linux, BSD, Jython, IronPython


